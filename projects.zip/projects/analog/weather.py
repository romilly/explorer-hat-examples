import explorerhat as eh
from time import sleep

while True:
    v1 = eh.analog.one.read()
    centigrade = 100.0 * (v1 - 0.5)
    farenheit = 32 + 9 * centigrade / 5.0
    print('temperature is %4.1f degrees C or %4.1f degrees F'
          % (centigrade, farenheit))
    v2 = eh.analog.two.read()
    light_level = 'low'  if v2 > 3.5 else 'high'
    print('light level is %s' % light_level)
    sleep(1)
