# Examples using the Explorer HAT pro on-board LEDs.

These are projects from *Explorer Hat Tricks* - an ebook about the Pimoroni Explorer Hat Pro which you can buy on [Leanpub](https://leanpub.com/explorerhattricks/). That means you get a 40-day no-quibble **money back guarantee**).

No wiring is required.

A single blink: [hello.py](hello.py)

Blinking for ever: [blink.py](blink.py)

Blink multiple LEDs [leds.py](leds.py)

Blink all the things! [all-blink.py](all-blink.py)